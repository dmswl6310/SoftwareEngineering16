import java.util.ArrayList;
import java.util.List;

public class Game {
List<Object> people;
public void Game() {
	people=new ArrayList<Object>();
}
public void insertPerson(String name) {
	people.add(name);
}
public void deletePerson(int index) {
	people.remove(index);
}
public void randomPerson() {
	//�������� �̾Ƽ� ���
}
}
