import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Panel;
import java.awt.event.WindowEvent;

public class Software16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//GUI-Cardlayout�� �̿��Ͽ� setvisible(true)�� ȭ���� ���δ�
		CardLay cl=new CardLayout();
		cl.setVisible(true);
		cl.setSize(500,500);
	}
public void windowClosing(WindowEvent e){
	System.exit(1);;
	
}

}
class CardLay extends Frame implements ActionListener{
	Button b1, b2;
	Panel[] p=new Panel[10];
	CardLayout card;
	Cardalay() {
		//�ǳڰ� �׼Ǹ����� �߰�+add�� �ǳ� ���
	}
	public void actionPerformed(actionEvent e) {
		//ī�庯ȯ
	}
}
