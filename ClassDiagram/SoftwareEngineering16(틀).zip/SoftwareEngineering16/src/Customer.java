
public class Customer {
String name;
int age;
public void getInfo() {

}
}

class User extends Customer{
	void createComment() {
		
	}
}
class Unuser extends Customer{
	
}
