
public class Restaurant {
private String name;
private String group;
private String location;
private int cost;
private String info;

}
